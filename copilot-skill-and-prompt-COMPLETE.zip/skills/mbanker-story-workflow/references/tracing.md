# Playwright + mBanker trace capture and analysis

## Capture sequence: the critical optimization

The app's `__trace` dashboard may capture substantial end-to-end data. Therefore:

1. Open trace dashboard at `http://localhost:8080/mBanker/__trace/`; inspect actual labels and controls.
2. Open the application and navigate to within **one action** (or the smallest possible action sequence) of reproducing the issue.
3. Prepare test data, input values, and UI state **before starting the recording**.
4. Select a descriptive session label (`TICKET-before-YYYYMMDD-HHMMSS`, then analogous `after` label); if the UI constrains session names, adapt safely and record the actual name.
5. Click **Start** via Playwright and verify recording was enabled.
6. Perform the exact critical interaction.
7. Immediately click **Stop** via Playwright, even if the scenario failed or timed out, and verify recording stopped.
8. Enumerate session directories under `C:\Users\LC5782686\workspace\trace\glass-trace`; identify the output from matching label and timestamp.
9. Never leave a recording running during analysis. Do not take 10-MB logs into context.

Do not presume there are hidden trace APIs, that trace starts/stops via GET requests, or that exact labels never change. Drive visible controls unless the repository documents another supported method.

## First inspection: metadata only

For a suspected session, first show:

- Resolved session directory, file count, total bytes, last-modified timestamps
- Top few largest files and their extensions
- Capture start/stop markers, if safely discoverable
- Which files likely contain errors, requests, UI events, spans, or call-graph information

Use `scripts/Inspect-MBankerTrace.ps1` for **metadata-only** listing if PowerShell execution is available. Do not run a script without reviewing it first.

Example command (from repository root; update relative script location if needed):

```powershell
powershell -NoProfile -File .github\skills\mbanker-story-workflow\scripts\Inspect-MBankerTrace.ps1
powershell -NoProfile -File .github\skills\mbanker-story-workflow\scripts\Inspect-MBankerTrace.ps1 -Session 'ABC-1234-before'
```

The script does **not** dump trace content or delete/create anything.

## Targeted investigation

- Use file names, time range, correlation IDs, request URLs, handler names, exception classes, component names, and known input identifiers to narrow the search.
- Read small spans around relevant matches, not complete logs. Prefer capped command output and incremental search.
- When multiple services appear, reconstruct the path from UI event → component handler → service → network endpoint → backend handler → state/database operation → response → UI update.
- Identify the **earliest divergence** that explains the observed behavior. A downstream exception might be a symptom.
- Mark any unobservable spans explicitly. Don't infer what the trace cannot show.
- Avoid exposing request bodies, cookies, bearer tokens, full account numbers, identifiers, or customers' personal data in summaries.

## Before/after comparison

Compare on the **same** initial state and action wherever feasible:

| Topic | Before | After |
|---|---|---|
| UI visible behavior | observed | observed |
| Relevant request / event | observed | observed |
| Key handler sequence | observed | observed |
| Error/warning evidence | observed | observed |
| Resulting state | observed | observed |
| Acceptance criteria | failed/unknown | passed/failed/unknown |

Compare *meaningful* events and outcomes; timestamps, session IDs, and unrelated request order may differ legitimately. A missing exception alone is not proof of a fix.

## Failure handling

- If recording did not start, do not claim to have captured a trace.
- If a recording is interrupted, prioritize stopping the trace and report its status.
- If the session folder is missing, check dashboard session naming and timestamps before concluding no trace exists.
- If captures become too large, shorten interaction or use approved trace filters; never invent undocumented switches.
