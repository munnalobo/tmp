# Required report formats

## PLAN checkpoint report (before implementation)

Report in this order; see [plan-and-screenshots.md](plan-and-screenshots.md) for expanded template:

1. Story key, summary, local source folder, mode = PLAN, no code changed.
2. Numbered, testable acceptance criteria (`R1` ...).
3. Relevant confirmed class/method/file map; mark hypotheses as hypotheses.
4. Exact UI preconditions, reproduction steps, actual vs expected, screenshots and before-trace reference if collected.
5. Root cause confidence and evidence, remaining unknowns.
6. A requirement-to-change-to-test matrix.
7. Minimal change proposal, regression scope, risks, and blockers.
8. **Stop for explicit approval.**

## EXECUTE completion report (only after plan approval)

```markdown
## Story / plan
- Ticket and approved plan: ...
- Branch: ...
- Status: verified / implemented, validation incomplete / blocked / investigation only

## Implementation
- `path/file`: change and reason
- Scope deviations, if any (must be reapproved if material): ...

## Requirements verification
| Req | Expected | Actual after | Evidence | Status |
|---|---|---|---|---|
| R1 | ... | ... | test / screenshot / trace | verified / failed / unverified |

## Before vs after
| Checkpoint | Before evidence | After evidence | Conclusion |
|---|---|---|---|
| Browser UI | screenshot path | screenshot path | ... |
| Execution trace (if relevant) | session path | session path | ... |

## Tests and regressions
- Command/suite, passed/failed/skipped, environment: ...
- Replayed Playwright steps and result: ...
- Adjacent/negative scenarios: ...

## Residual risks / unknowns
- ...
```

Do not fabricate tests, screenshots, trace sessions, branches or source references.
