# Planning checkpoint, source mapping and screenshot parity

## Required PLAN review template

```markdown
# Investigation and Implementation Plan — <TICKET>
Status: AWAITING APPROVAL (no source changes)

## Requirements from local story folder
- R1: ... [source file/comment/attachment reference]
- R2: ...
- Unresolved questions/conflicts: ...

## Code impact analysis
| Req | Confirmed source path and class/method | Observed evidence | Smallest proposed change | Validation |
|---|---|---|---|---|
| R1 | `...` / `Class.method` | ... | ... | ... |

## Reproduction/baseline
- Environment and role:
- Route, viewport, feature flags, safe test data:
- Exact numbered browser steps:
- Actual and expected behavior:
- Reproduced? yes/no/not applicable:
- Before screenshot files: ...
- Before trace session: ... / omitted because ...

## Diagnosis
- Root cause and confidence (confirmed/likely/unknown):
- Evidence: trace events, source refs, Playwright observations:
- Alternate hypotheses ruled out or outstanding:

## Proposed implementation
- Files/classes to change and why:
- Expected change in execution flow:
- Invariants and security boundaries to preserve:

## Verification plan
- Automated regression tests and commands:
- Browser replay and screenshot checkpoints:
- After-trace comparison (if relevant):
- Adjacent/negative test:

## Risks and blockers
- ...

## APPROVAL GATE
Await explicit approval to create branch and modify application files.
```

## Screenshot capture requirements

Create the **before** and **after** screenshot pair from **observed live application UI** using Playwright MCP. Ticket attachments can supplement but cannot replace evidence from the running app.

Names can resemble:
- `<TICKET>-01-before-action.png` (when current screen matters)
- `<TICKET>-02-before-result.png` (actual failure / baseline)
- `<TICKET>-01-after-action.png` (same checkpoint if relevant)
- `<TICKET>-02-after-result.png` (corrected outcome)

Use screenshot abilities actually exposed by Playwright MCP; never invent a tool argument. Record actual output locations (even if the tool chooses them), the tested URL, viewport, role and test data/state. Keep browser zoom and viewport identical between pairs. When state cannot be held constant, make the difference explicit. Use a bounded number of focused screenshots to avoid clutter.

For visual differences, compare the screenshots together while acknowledging differences from dynamic timestamps, random identifiers, loading states, and personalized content. **Visual parity does not establish functional correctness.** Always pair with test assertions and, if meaningful, traces.

Store screenshot and trace evidence locally outside Git, e.g. under `%LOCALAPPDATA%\mBankerAgent\Stories\<TICKET>\`; do not expose/customer data or commit generated evidence. Do not claim a screenshot exists without verifying the returned file or evidence reference.

## When the plan is uncertain

If reproduction, trace or requirement meaning is unresolved, report it. Recommend focused investigation and ask for a decision. Do not generate an executable fix plan pretending to know the root cause. Re-plan if material surprises arise during execution; approved scope is not unlimited license.
