<#
.SYNOPSIS
Read-only, size-limited trace session metadata inspection for mBanker.
.DESCRIPTION
Without -Session: lists the most recently modified session directories.
With -Session: lists file count, total bytes, and up to MaxFiles largest files.
Does NOT print log content, execute code in traces, or modify files.
.EXAMPLE
powershell -NoProfile -File .\Inspect-MBankerTrace.ps1 -Session 'ABC-1234-before'
#>
[CmdletBinding()]
param(
    [string]$TraceRoot = 'C:\Users\LC5782686\workspace\trace\glass-trace',
    [string]$Session,
    [ValidateRange(1, 100)] [int]$MaxFiles = 15,
    [ValidateRange(1, 100)] [int]$MaxSessions = 15
)

$ErrorActionPreference = 'Stop'
if (-not (Test-Path -LiteralPath $TraceRoot -PathType Container)) {
    throw "Trace root not found or inaccessible: $TraceRoot"
}

if ([string]::IsNullOrWhiteSpace($Session)) {
    Get-ChildItem -LiteralPath $TraceRoot -Directory -ErrorAction Stop |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First $MaxSessions Name, LastWriteTime, FullName |
        Format-Table -AutoSize
    return
}

# Session must be a single child folder, never an arbitrary relative path.
if ($Session -notmatch '^[a-zA-Z0-9][a-zA-Z0-9._-]{0,119}$' -or $Session -eq '.' -or $Session -eq '..') {
    throw 'Session name must be a single safe directory name (letters/digits, dot, underscore or hyphen).'
}
$SessionPath = Join-Path -Path $TraceRoot -ChildPath $Session
if (-not (Test-Path -LiteralPath $SessionPath -PathType Container)) {
    throw "Session directory does not exist: $SessionPath"
}
$files = @(Get-ChildItem -LiteralPath $SessionPath -File -Recurse -ErrorAction Stop)
$totalBytes = 0L
foreach ($f in $files) { $totalBytes += $f.Length }
Write-Output "Session: $Session"
Write-Output "Path: $SessionPath"
Write-Output "Files: $($files.Count)"
Write-Output "Total bytes: $totalBytes"
Write-Output 'Largest files (metadata only):'
$files |
    Sort-Object Length -Descending |
    Select-Object -First $MaxFiles Name, Length, LastWriteTime, DirectoryName |
    Format-Table -AutoSize
