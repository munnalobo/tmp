# mBanker Copilot Skill + Prompt — Complete Package

This ZIP is intentionally arranged with **visible folders** (`skills` and `prompts`). An earlier ZIP had a `.github` folder, which is hidden by default in some file browsers and made the ZIP appear to contain only `INSTALL.md`.

## Contents

- `skills/mbanker-story-workflow/SKILL.md` — main skill instructions.
- `skills/mbanker-story-workflow/references/` — setup, trace, screenshots, and reporting guidance.
- `skills/mbanker-story-workflow/scripts/Inspect-MBankerTrace.ps1` — read-only trace helper.
- `prompts/mbanker-story.prompt.md` — ready-to-use Copilot prompt file.
- `prompt.md` — a convenient duplicate of the full prompt for reading and copying.

## Installation into IntelliJ / GitHub Copilot repository

1. Unzip this package.
2. Open the **root folder of the mBanker Git repository**.
3. Create `.github` in that root if it does not exist.
4. Copy the extracted `skills` folder into `<repo>/.github/skills` (merge, do not overwrite unrelated skills).
5. Copy the extracted `prompts` folder into `<repo>/.github/prompts` (merge, do not overwrite unrelated prompts).
6. Do **not** copy the extra top-level `prompt.md` into `.github`: it is only a convenient readable copy.

Final locations:

```text
<repo>/
  .github/
    skills/
      mbanker-story-workflow/
        SKILL.md
        references/
          environment.md
          tracing.md
          plan-and-screenshots.md
          report.md
        scripts/
          Inspect-MBankerTrace.ps1
    prompts/
      mbanker-story.prompt.md
```

## Usage

First request:
`/mbanker-story ABC-1234`

Agent performs plan-only discovery, requirements mapping, baseline screenshots and focused tracing when safe/useful. It must **stop for approval** without source changes.

After reviewing the plan:
`I approve the ABC-1234 plan. Execute using the mbanker-story-workflow skill.`

The agent should create the story branch, implement the scoped fix, retest with Playwright, and capture comparable after screenshots/traces when useful.

## Environment assumptions

- Tickets and relevant attachments/comments are **already in local story folders**. No Jira MCP is required.
- Playwright MCP is **already configured**.
- Startup script `core_startup.ps1`; trace dashboard `http://localhost:8080/mBanker/__trace/`.
- Trace directory `C:\Users\LC5782686\workspace\trace\glass-trace`.
- Browser and trace use must respect workplace security and avoid production-impacting operations.
