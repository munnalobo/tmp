# mBanker workflow for JetBrains Junie (IntelliJ)

This package contains the complete **Plan → Approve → Execute → Verify** skill for JetBrains Junie. It is a Junie-specific conversion of the earlier Copilot package. Its workflow and trace helper are retained.

## Included (all visible files)

```text
INSTALL.md
junie-prompt.md                 # Complete, pasteable workflow prompt
AGENTS.md                       # Short persistent project rules
skills/
  mbanker-story-workflow/
    SKILL.md
    references/
      environment.md
      tracing.md
      plan-and-screenshots.md
      report.md
    scripts/
      Inspect-MBankerTrace.ps1
```

## Install

In your **mBanker repository root**, create `.junie` if it doesn't exist. Then copy:

- This package's `AGENTS.md` -> `<project-root>/.junie/AGENTS.md`. **Merge with an existing file; don't overwrite existing team guidelines.**
- This package's entire `skills` directory -> `<project-root>/.junie/skills/`. Preserve its nested `mbanker-story-workflow` folder.
- `junie-prompt.md` is optional: save anywhere convenient and paste its content into Junie chat if you want the **full** prompt. Skills don't need you to paste the full prompt each time.

Ensure the final main skill file is:
`<project-root>/.junie/skills/mbanker-story-workflow/SKILL.md`

## Use in IntelliJ AI Chat

1. Open AI Chat and choose **Junie by JetBrains** as the agent.
2. Choose **Plan** mode (for versions that expose Plan) and **Safe/Auto command permissions** rather than Brave.
3. Ask: `Use the mbanker-story-workflow skill to PLAN ABC-1234. Read the local story folder, map classes, reproduce with Playwright if connected, capture before evidence, and stop for approval.`
4. Review the plan; then switch to the appropriate implementation mode and say: `I approve the ABC-1234 plan as written. Execute and verify it.`

In the standalone Junie tool window, **Ask mode** is code-read-only, so it might not be able to create screenshots or run recording actions. Use Ask for static code discovery, or Code mode with the instruction `PLAN ONLY — STOP BEFORE SOURCE EDITS`; never use Brave mode just to bypass the gate.

Junie CLI additionally advertises enabled skills as `/<skill-name>` or `$<skill-name>`; run `/skills` to check discovery. The same shortcut availability is not assumed for AI Chat.

## MCP (important difference from Copilot)

Playwright MCP was reported as **already available to Copilot**. That does **not** guarantee it's exposed to Junie.

- Junie in IntelliJ AI Chat: check `Settings → Tools → AI Assistant → Model Context Protocol (MCP)`; then `Settings → Tools → AI Assistant → Agents` and enable **Pass custom MCP servers** as permitted by the organization.
- Standalone Junie plugin: check `Settings → Tools → Junie → MCP Settings` (or the project `.junie/mcp/mcp.json`).

Do not add a second Playwright server if the tool is already visible. Do not circumvent company policy. Do not assume Jira MCP is required; all ticket data is local.

## Known mBanker paths

- Local ticket folders: parent location unknown; the agent must discover or request the single parent folder.
- Startup script: `core_startup.ps1` (inspect first).
- UI trace dashboard: `http://localhost:8080/mBanker/__trace/`
- Trace root: `C:\Users\LC5782686\workspace\trace\glass-trace`

## Safe first-run verification prompt

> Use the mbanker-story-workflow skill in PLAN mode. Verify you can read SKILL.md and the local story packet folder; enumerate available Playwright MCP tools; locate core_startup.ps1 and the trace directory. Do not alter application code, Git branches or server data. Report any blocked capability and stop.

## Notes

- **No feature branch or application edits during PLAN.** The plan is a deliberate human review checkpoint.
- UI before/after snapshots should match on input, role, URL and viewport when feasible.
- Some investigation operations (starting services, recording traces, screenshots) still have side effects. Approval is needed if they could touch non-test environments or sensitive data.
- Junie guidance documentation: https://junie.jetbrains.com/docs/agent-skills.html and https://www.jetbrains.com/help/ai-assistant/junie-agent.html
